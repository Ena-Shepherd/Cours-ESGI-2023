/*****************************************************
* \file    livre.c
* \author  Yohann MALEY
* \date    15 décembre 2022
* \brief   Contient le code des fonctions du livre
* \version 1.0
******************************************************/

#include "livre.h"

#define NEW(nom , type, taille) nom = ( ( type *) malloc( sizeof( type ) * taille ) ); if (nom == NULL) exit(125)

void Livre_creer(Livre **livre, const char *nom, const char *auteur, const char *editeur, const char *code_barre)
{
    if ( livre == NULL) return;
    NEW( *livre, Livre, 1 );
    NEW( (*livre)->nom, char, strlen(nom)+1 ) ;
    strcpy((*livre)->nom,nom);
    NEW( (*livre)->auteur, char, strlen(auteur)+1 ) ;
    strcpy((*livre)->auteur,auteur);
    NEW( (*livre)->editeur, char, strlen(editeur)+1 ) ;
    strcpy((*livre)->editeur,editeur);

    for (unsigned  i = 0; i < 13; i++) (*livre)->code_barre[i] = code_barre[i];
}


void Livre_set(Livre *livre, const char *attribut, const char *valeur)
{
    if ( livre == NULL) return;
    if (strcmp(attribut, "nom") == 0) {
        free((livre)->nom);
        NEW( (livre)->nom, char, strlen(valeur)+1 ) ;
        strcpy(livre->nom,valeur);
    }
    else if (strcmp(attribut, "auteur") == 0) {
        free((livre)->auteur);
        NEW( (livre)->auteur, char, strlen(valeur)+1 ) ;
        strcpy((livre)->auteur,valeur);
    }
    else if (strcmp(attribut, "editeur") == 0) {
        free((livre)->editeur);
        NEW( (livre)->editeur, char, strlen(valeur)+1 ) ;
        strcpy((livre)->editeur,valeur);
    }
    else if (strcmp(attribut, "code_barre") == 0)
    {
        for (int i = 0; i < 13; i++) livre->code_barre[i] = valeur[i];
    }
}

const char *Livre_get(const Livre *livre, const char *attribut)
{
    if ( livre == NULL) return NULL;
    if (strcmp(attribut, "nom") == 0) return livre->nom;
    else if (strcmp(attribut, "auteur") == 0) return livre->auteur;
    else if (strcmp(attribut, "editeur") == 0) return livre->editeur;
    else if (strcmp(attribut, "code_barre") == 0) return livre->code_barre;
    return NULL;
}



void Livre_afficher(const Livre *livre)
{
     if ( livre == NULL) return;
    printf("--------------------\n");
    printf("> Nom: %s\n", livre->nom);
    printf("> Auteur: %s\n", livre->auteur);
    printf("> Editeur: %s\n", livre->editeur);
    printf("> Code barre: %s\n", livre->code_barre);
    printf("--------------------\n");
}
void Livre_liberer(Livre ** livre) {
    if ( livre == NULL) return;
    if ( *livre == NULL) return;

    if ((*livre)->nom != NULL) free((*livre)->nom );
    if ((*livre)->auteur != NULL) free((*livre)->auteur );
    if ((*livre)->editeur != NULL) free((*livre)->editeur );
    free(*livre);
    *livre=NULL;
}
int C_3()
{
    Livre* livre = NULL;
    Livre_creer(&livre, "Le petit prince", "Antoine de Saint-Exupéry", "Gallimard", "9782070413095");
    Livre_afficher(livre);

    Livre_set(livre, "nom", "Le petit prince 2");
    Livre_set(livre, "auteur", "Antoine de Saint-Exupéry 2");
    Livre_set(livre, "editeur", "Gallimard 2");
    Livre_set(livre, "code_barre", "9782070413096");
    Livre_afficher(livre);

    printf("Nom: %s", Livre_get(livre, "nom"));
    printf("Auteur: %s", Livre_get(livre, "auteur"));
    printf("Editeur: %s", Livre_get(livre, "editeur"));
    printf("Code barre: %s", Livre_get(livre, "code_barre"));

    Livre_liberer(&livre);
    return 0;
}
