/*****************************************************
* \file    main.c
* \author  Yohann MALEY
* \date    15 décembre 2022
* \brief   Contient le code des fonctions du main
* \version 1.0
******************************************************/

#include "menu.h"

int main(){
    menu();
    return 0;
}
