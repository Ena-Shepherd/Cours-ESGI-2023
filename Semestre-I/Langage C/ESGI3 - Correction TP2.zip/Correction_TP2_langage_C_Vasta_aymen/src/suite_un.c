#include <locale.h>
#include <stdio.h>
#include <math.h>
#include "PTP2/suite_un.h"
#include "PTP2/second_degre.h"
// Cette fonction calcule la suite U[n], U[n] = (1/2) * (U[n-1] + 2/U[n-1]), U[0] = 2.0
void Suite_un()
{
    // D�claration des variables
    unsigned int n;
    double U = 2.0;

    // Demander � l'utilisateur de saisir un entier
    printf("Entrez n :");
    while(scanf("%u", &n) != 1)
    {
        // Afficher un message d'erreur
        printf("Veuillez entrer un chiffre > 0 : ");
        // Scanner n'importe quoi pour vider le buffer
        scanf("%*s");
    }

    // Boucle pour calculer U[n] selon la suite
    for (unsigned int i = 0; i <= n; i += 10)
    {
        for (unsigned int j = 0; j < i; ++j)
        {
            U = (1.0/2.0) * (U + (2.0/U));
        }
        printf("U%d = %.5f\n", i, U);
    }

    // Afficher le r�sultat de U[n]
    printf("Le resultat de U[%d] est %.5f.\n\n", n, U);
    {
        double res[2];
        equation2(1,0,-2,res );
        // Afficher le r�sultat de la racine carr�e de 2
        printf("Cette serie converge vers le resultat positif de la resolution de l equation x^2 - 2 qui est %.5f.\n",res[0]);
    }

    return ;
}
