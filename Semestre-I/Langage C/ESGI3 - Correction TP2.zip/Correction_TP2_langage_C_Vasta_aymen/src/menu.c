#include <stdio.h>
#include <stdlib.h>
#include "PMenu/menu.h"
#include "PTP2/TP2.h"

void Pause(void) {
    printf("taper une touche pour continuer >");
    getchar();getchar();
}
void Menu()
{
    //Déclare les variables.
	short exec = 1,choiceEx ;
	do
	{
		//Vide la console.
		system("cls");
		//Demande à l'utilisateur de choisir un exercice.
		printf("Quelle Exercice voulez vous executer ?\n(1-5 : Exercice) (0 : Return)\n");
        while(scanf("%hu", &choiceEx) != 1) {
            // Afficher un message d'erreur
            printf("Veuillez entrer un chiffre : ");
            // Scanner n'importe quoi pour vider le buffer
            scanf("%*s");
        }
		//Vide la console.
		system("cls");

		//Switch en fonction du choix de l'utilisateur
		switch (choiceEx)
		{
			case 0:
				//Retour en arrière.
				break;
			case 1:
				//Lance la fonction de l'exercice 1.
				TP2_Ex1();
				break;

			case 2:
				//Lance la fonction de l'exercice 2.
				TP2_Ex2();
				break;

			case 3:
				//Lance la fonction de l'exercice 3.
				TP2_Ex3();
				break;

			case 4:
				//Lance la fonction de l'exercice 4.
				TP2_Ex4();
				break;

			case 5:
				//Lance la fonction de l'exercice 5.
				TP2_Ex5();
				break;

			default:
				//Affiche un message d'erreur.
				printf("Choix invalide.\n");
				break;
		}

		//Message d'attente.
		printf("\n\n\nAppuyez sur une touche pour continuer...");
		//Pause.
		Pause();
		//Vide la console.
		system("cls");
		//Demande à l'utilisateur s'il veut continuer.
		printf("Voulez vous rester sur le TP 2?\nTrue (1), False (0)\n");
        while(scanf("%hu", &exec) != 1) {
            // Afficher un message d'erreur
            printf("Veuillez entrer un chiffre : ");
            // Scanner n'importe quoi pour vider le buffer
            scanf("%*s");
        }
	} while (exec == 1);
}
