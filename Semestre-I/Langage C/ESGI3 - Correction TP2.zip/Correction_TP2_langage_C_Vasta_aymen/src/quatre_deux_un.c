#include "PTP2/quatre_deux_un.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>
#include <ctype.h>

// cr�e une fonction qui permet de lancer une partie de 4-2-1.
void quatre_deux_un_oldversion(void)
{

// Initialise le g�n�rateur de nombres al�atoires.
    srand(time(NULL));

// D�claration de variables qui seront n�cessaire pour la partie.
    unsigned nb_parties;
    unsigned c, d = 0, e, b = 0, a = 0, l = 0, partieGagnee = 0, partiePerdue = 0;
    double pourcentageReussite;

// Demande � l'utilisateur le nombre de parties souhait�es.
    printf("Combien de parties voulez-vous jouer : ");

// Tant que le nombre entr�e par l'utilisateur n'est pas un nombre entier, une boucle est activ�e pour que l'utilisateur entre un nombre entier.
    while(scanf("%u", &nb_parties) != 1)
    {
        // Affiche un message d'erreur
        printf("Veuillez entrer un chiffre : ");
        // Scanne n'importe quoi pour vider le buffer
        scanf("%*s");
    }

// Ajoute un saut de ligne pour s�parer les donn�es entr�e par l'utilisateur.
    printf("\n");



// Boucle qui permet de jouer le nombre de parties demand�s par l'utilisateur.
    for (unsigned p = 1; p <= nb_parties; ++p)
    {

        // D�claration et d�finition des variables n�cessaires pour chaque partie.
        unsigned short  nb_des = 3; // Nombre de d�s
        unsigned short  chiffres[3] = {4, 2, 1}; // Chiffres � trouver
        unsigned short  trouves[3] = {0, 0, 0}; // Chiffres trouv�s
        unsigned short  reste = 0;
        e = 0;

// Boucle qui permet � l'utsilisateur de jouer 3 tours.
        for (l = 1; l <= 3; l++)
        {
            // Affiche � l'utilisateur le tour et le nombre de d�s qu'il peut jouer.
            printf("Lancer %d avec %d de", l, nb_des);
            // Teste si le nombre de d�s est sup�rieur � 1 pour modifier le message affich� � l'utilisateur.
            if(nb_des > 1)
            {
                printf("s");
            }
            printf(" : ");
            unsigned short  nb_trouves = 0;
            unsigned short  trouves2[3] = {0, 0, 0};
            // Boucle qui permet de choisir un nombre entre 1 et 6 pour chaque d�s lanc�.
            for (unsigned short i = 0; i < nb_des; i++)
            {
                unsigned short int resultat = rand() % 6 + 1;
                // Affiche le r�sultat al�atoire pour chaque d�s.
                printf("%d ", resultat);
                // Boucle qui teste si le r�sultat du d�s est �gal � 4, 2 ou 1 et si ce nombre n'as pas �t� trouv� pr�c�demment pour incr�menter le nombre de chiffres trouv�s et le nombre de d�s gard�s.
                for (unsigned short j = 0; j < 3; j++)
                {
                    if (resultat == chiffres[j] && trouves[j] == 0)
                    {
                        trouves[j] = 1;
                        trouves2[j] = trouves[j];
                        nb_trouves++;
                        a++;
                        e++;
                        break;
                    }
                }
            }
            // R�duit le nombre de d�s disponibles � l'utilisateur en soustrayant le nombre de d�s trouv�s au nombre de d�s d�clar�.
            nb_des -= nb_trouves;

            // D�clare des variables temporaires.
            c = 3 - a;
            d = e;
            b = a;

            // Teste si des chiffres on �t� trouv� au tour courant pour afficher la liste des chiffres trouv�s
            if (a > 0)
            {
                printf("Je garde ");
                for (int i = 0; i < 3; i++)
                {
                    if (trouves2[i] == 1)
                    {
                        printf("%d", chiffres[i]);
                        if (c < 2)
                        {
                            printf(" et ");
                            // Incr�mente le nombre de chiffre d�clar�s afin de simplifier l'affichage.
                            c++;
                        }
                    }
                }
            }

            // Affecte la valeur de b � a.
            a = b;
            // Teste si aucun chiffre n'a �t� trouv� � ce tour pour afficher un message adapt�.
            if (a == 0)
            {
                printf("Je ne garde rien");
            }
            // R�initialise le nombre de chiffres trouv�s � ce tour et stoke le nombre de chiffres trouv�s total.
            if (e > 0)
            {
                printf("   [");
                for (int i = 0; i < 3; i++)
                {
                    if (trouves[i] == 1)
                    {
                        printf("%d", chiffres[i]);
                        // Teste si le nombre de chiffres est sup�rieur � deux afin de modifier la vue de la liste des chiffres trouv�s.
                        if (d >= 2)
                        {
                            printf(",");
                            // R�duit le nombre de chiffres d�clar�s � ce tour.
                            d--;
                        }
                    }
                }
                // Ferme la liste des chiffres trouv�s.
                printf("]");
            }

            // Affiche un saut de ligne.
            printf("\n");
            // R�initialise les variables temporaires.
            b = 0;
            a = 0;
            c = 0;
            reste = 0;
            // Boucle qui teste si tous les chiffres 4, 2 et 1 ont �t� trouv�s
            for (int i = 0; i < 3; i++)
            {
                if (trouves[i] == 0)
                {
                    // Modifie la valeur de reste si un chiffre n'� pas �t� trouv�.
                    reste = 1;
                    break;
                }
            }
            // Teste si reste a �t� modifi� par la boucle pr�c�dente et termine la partie en cas de succ�s.
            if (reste == 0)
            {
                break;
            }
        }

        // Teste si reste � �t� modifi� et le nombre de chiffres trouv�s � �t� sup�rieur � 0 pour afficher un message de victoire.
        if (reste == 0)
        {
            printf("Partie %d gagnee en %d coup", p, l);
            // Incr�mente le nombre de parties gagn�es.
            partieGagnee++;
            // Teste si le nombre de tour est sup�rieur � un pour modifier le message affich� � l'utilisateur.
            if(l>1)
            {
                printf("s\n\n");
            }
        }

        // Teste si reste n'a pas �t� modifi� par la boucle pr�c�dente pour afficher un message de d�faite.
        else
        {
            printf("Partie %d Perdue\n\n", p);
            // Incr�mente le nombre de parties perdues.
            partiePerdue++;
        }
    }

// Calcul le pourcentage de parties gagn�es par l'utilisateur.
    pourcentageReussite = (float) (partieGagnee * 100) / (partieGagnee + partiePerdue);

// Affiche le nombre de parties et le pourcentage de gains obtenu par l'utilisateur.
    printf ("Vous avez joue %d parties, %d gagnees pour %d perdue", nb_parties, partieGagnee, partiePerdue);
// Teste si le nombre de parties perdues est sup�rieur � un pour modifier le message affich� � l'utilisateur.
    if(partiePerdue>1)
    {
        printf("s");
    }
    printf(" soit %.2f %% de gain", pourcentageReussite); // Affiche le pourcentage des parties gagn�es par l'utilisateur.
}





// cr�e une fonction qui permet de lancer une partie de 4-2-1.
void quatre_deux_un(void)
{

// Initialise le g�n�rateur de nombres al�atoires.
    srand(time(NULL));

// D�claration de variables qui seront n�cessaire pour la partie.
    unsigned nb_parties;
    unsigned  l = 0, partieGagnee = 0, partiePerdue = 0;
    double pourcentageReussite;

// Demande � l'utilisateur le nombre de parties souhait�es.
    printf("Combien de parties voulez-vous jouer : ");

// Tant que le nombre entr�e par l'utilisateur n'est pas un nombre entier, une boucle est activ�e pour que l'utilisateur entre un nombre entier.
    while(scanf("%u", &nb_parties) != 1)
    {
        // Affiche un message d'erreur
        printf("Veuillez entrer un chiffre : ");
        // Scanne n'importe quoi pour vider le buffer
        scanf("%*s");
    }

// Ajoute un saut de ligne pour s�parer les donn�es entr�e par l'utilisateur.
    printf("\n");

// Boucle qui permet de jouer le nombre de parties demand�s par l'utilisateur.
    for (unsigned p = 1; p <= nb_parties; ++p)
    {

        // D�claration et d�finition des variables n�cessaires pour chaque partie.
        unsigned short  nb_des = 3; // Nombre de d�s
        // 0,1,2,3,4,5,6
        // 0,1,2,3,4,5,6
        unsigned short  chiffres[7] = {-1,0,0,1,0,1,1}; // Chiffres � trouver
        unsigned short  memo[2]= {0,0};
        unsigned short  nb_trouves;
        unsigned short int resultat;
// Boucle qui permet � l'utsilisateur de jouer 3 tours.
        for (l = 1; l <= 3; ++l)
        {
            // Affiche � l'utilisateur le tour et le nombre de d�s qu'il peut jouer.
            printf("Lancer %d avec %d de", l, nb_des);
            // Teste si le nombre de d�s est sup�rieur � 1 pour modifier le message affich� � l'utilisateur.
            if(nb_des > 1)
            {
                printf("s");
            }
            printf(" : ");
            nb_trouves = 0;
            // Boucle qui permet de choisir un nombre entre 1 et 6 pour chaque d�s lanc�.
            for (unsigned short i = 0; i < nb_des; i++)
            {
                resultat = rand() % 6 + 1;
                // Affiche le r�sultat al�atoire pour chaque d�s.
                printf("%d ", resultat);
                // Boucle qui teste si le r�sultat du d�s est �gal � 4, 2 ou 1 et si ce nombre n'as pas �t� trouv� pr�c�demment pour incr�menter le nombre de chiffres trouv�s et le nombre de d�s gard�s.
                for (unsigned short j = 0; j < 3; j++)
                {
                    if (chiffres[resultat]==0)
                    {
                        chiffres[resultat]=1;
                        memo[0]+=resultat;
                        nb_trouves++;
                        break;
                    }
                }
            }
            // R�duit le nombre de d�s disponibles � l'utilisateur en soustrayant le nombre de d�s trouv�s au nombre de d�s d�clar�.
            nb_des -= nb_trouves;

            // Teste si des chiffres on �t� trouv� au tour courant pour afficher la liste des chiffres trouv�s
            if (memo[1] != memo[0] )
            {
                printf("Je garde ");
                switch ( memo[0] )
                {
                case 1 :
                case 2 :
                case 4 :
                    printf("%u",memo[0]);
                    break;
                case 7 :
                    printf("4 et 2 et 1");
                    break;
                case 3 :
                    printf("2 et 1");
                    break;
                case 6 :
                    printf("4 et 2");
                    break;
                case 5 :
                    printf("4 et 1");
                    break;
                }
                memo[1]+=memo[0];
                memo[0]=0;
            }
            else
            {
                printf("Je ne garde rien");
            }

            printf("   [");
            switch ( memo[1] )
            {
            case 1 :
            case 2 :
            case 4:
                printf("%u",memo[1]);
                break;
            case 7 :
                printf("4,2,1");
                break;
            case 3 :
                printf("2,1");
                break;
            case 6 :
                printf("4,2");
                break;
            case 5 :
                printf("4,1");
                break;
            }

            // Ferme la liste des chiffres trouv�s.
            printf("]\n");

            if ( memo[1] == 7 ) break;
            // Affiche un saut de ligne.

        }

        // Teste si reste � �t� modifi� et le nombre de chiffres trouv�s � �t� sup�rieur � 0 pour afficher un message de victoire.
        if (memo[1]  == 7)
        {
            printf("Partie %d gagnee en %d coup", p, l);
            // Incr�mente le nombre de parties gagn�es.
            partieGagnee++;
            // Teste si le nombre de tour est sup�rieur � un pour modifier le message affich� � l'utilisateur.
            if(l>1)
            {
                printf("s\n\n");
            }
        }

        // Teste si reste n'a pas �t� modifi� par la boucle pr�c�dente pour afficher un message de d�faite.
        else
        {
            printf("Partie %d Perdue\n\n", p);
            // Incr�mente le nombre de parties perdues.
            partiePerdue++;
        }
    }

// Calcul le pourcentage de parties gagn�es par l'utilisateur.
    pourcentageReussite = (partieGagnee * 100.) / (partieGagnee + partiePerdue);

// Affiche le nombre de parties et le pourcentage de gains obtenu par l'utilisateur.
    printf ("Vous avez joue %d parties, %d gagnees pour %d perdue", nb_parties, partieGagnee, partiePerdue);
// Teste si le nombre de parties perdues est sup�rieur � un pour modifier le message affich� � l'utilisateur.
    if(partiePerdue>1)
    {
        printf("s");
    }
    printf(" soit %.2f %% de gain", pourcentageReussite); // Affiche le pourcentage des parties gagn�es par l'utilisateur.
}
