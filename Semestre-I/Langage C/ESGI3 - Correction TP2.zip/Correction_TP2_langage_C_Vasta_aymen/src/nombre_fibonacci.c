#include <stdio.h>
#include "PTP2/nombre_fibonacci.h"

// Fonction qui calcule et renvoie le nombre de Fibonacci d'un nombre donn�
long unsigned int fibonacci1(unsigned  int n)
{
    // Cas de base : si n est 0 ou 1 , renvoyer n
    if (n <=1) return n;
    // Calcule le nombre de Fibonacci en utilisant la formule r�cursive
    return fibonacci1(n - 1) + fibonacci1(n - 2);
}

long unsigned int fibonacci1_fast(unsigned  int n)
{
    if (n <=1) return n;
    long unsigned int U0=1, U1=1, U2=0;

    for (unsigned int i = 2; i <= n ; ++i)
        {
            U0 = U1 + U2;
            U2=U1;
            U1=U0;
        }
    return U0;
}
void Fibonacci(void)
{
    // Demande un nombre � l'utilisateur
    unsigned n;
    printf("Entrez n : ");
    while(scanf("%u", &n) != 1) {
        // Afficher un message d'erreur
        printf("Veuillez entrer un chiffre : ");
        // Scanner n'importe quoi pour vider le buffer
        scanf("%*s");
    }
    // Calcule et affiche le nombre de Fibonacci correspondant
    printf("Fibonacci de %u est %lu : F[%u] = %lu \n", n, fibonacci1(n), n, fibonacci1(n));
    printf("Fibonacci de %u est %lu : F[%u] = %lu \n", n, fibonacci1_fast(n), n, fibonacci1_fast(n));

    return ;
}
