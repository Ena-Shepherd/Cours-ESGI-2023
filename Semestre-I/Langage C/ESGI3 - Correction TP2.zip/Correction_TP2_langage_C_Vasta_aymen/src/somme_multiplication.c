#include <stdio.h>
#include <string.h>
#include "PTP1/somme_multiplication.h"

void SommeMultiplication()
{
	//Initie les variables.
	unsigned int i = 0;

	//Demande à l'utilisateur de saisir un nombre.
	printf("Indiquer le nombre que vous souhaitez : ");
	scanf_s("%u", &i);

	//Lance la fonction Somme.
	Somme(i);
	printf("\n");
	//Lance la fonction Multiplicateur.
	Multiplication(i);
	printf("\n");
}

void SommeStr(unsigned int i)
{
    static char buffer [512];// => i < 104

	//Initialise les variables.
	unsigned int rs = 0;
 	//Boucle qui additionne la variable rs.
	unsigned cpt=0;
    for (unsigned int j = 1; j <= i; rs += j++)
	{
		sprintf(&buffer[cpt], "%u + ", j);
		cpt = strlen(buffer);
	}
    buffer[strlen(buffer)-2]='\0';
	printf ("%s = %u\n",buffer, rs);
	printf ("%u = %s\n",rs, buffer);

}

void Somme(unsigned int i)
{
    if ( i < 104) {
        SommeStr(i);
        return;
    }
	//Initialise les variables.
	unsigned int rs = 0;
	//Boucle qui additionne la variable rs.

    for (unsigned int j = 1; j <= i; ++j,rs+=j);
	//Affiche le résultat.
	printf("%d = ", rs);
	for (unsigned int j = 1; j < i; ++j)
	{
		printf("%u + ", j);
	}
	printf("%u", i);

}
void Multiplication(unsigned int i)
{
	//Initie les variables.
	unsigned int rs = 1;

	//Boucle qui multiplie la variable rs.
	for (unsigned int j = 1; j <= i;rs*=j++);

	//Affiche le résultat.
	printf("%d! = %d = ", i, rs);
	for (unsigned int j = 1; j < i ; printf("%u x ", j++) );
	printf("%u", i);
}
