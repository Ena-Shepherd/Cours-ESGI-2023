#include "PTP1/TP1.h"
#include "PTP1/calcul_surface.h"
#include "PTP1/somme_multiplication.h"
#include "PTP1/etoiles.h"
#include "PTP1/le_plus_grand.h"
#include "PTP1/tableau.h"
#include "PTP1/table_ascii.h"
#include "PTP1/suite.h"

void TP1_Ex1()
{
	//Lance la fonction.
	CalculSurface();
}

void TP1_Ex2()
{
	//Lance la fonction.
	SommeMultiplication();
}

void TP1_Ex3()
{
	//Lance la fonction.
	LePlusGrand();
}

void TP1_Ex5()
{
	//Lance la fonction.
	Suite();
}

void TP1_Ex6()
{
	//Lance la fonction.
	Table_Ascii();
}

void TP1_Ex7()
{
	//Lance la fonction.
	Etoiles();
}

void TP1_Ex8()
{
	//Lance la fonction.
	Tableau();
}
