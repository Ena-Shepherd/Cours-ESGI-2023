#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "PTP2/fibonacci_nombre_or.h"

// Fonction qui calcule la valeur de Fibonacci � l'ordre n

double  fibonacci_double(unsigned int n)
{
    if (n <=1) return n;
    double U0=1, U1=1, U2=0;

    for (unsigned int i = 2; i <= n ; ++i)
    {
        U0 = U1 + U2;
        U2=U1;
        U1=U0;
    }
    return U0;
}
// Fonction principale qui calcule la suite O et le nombre d'or
void Fibonacci_nombre_or()
{
    // Initialisation de la variable n
    unsigned int n;
    // Demande � l'utilisateur de saisir un entier
    printf("Entrer N : ");
    // Boucle qui v�rifie si l'utilisateur entre un entier
    while(scanf("%u", &n) != 1)
    {
        // Affiche un message d'erreur
        printf("Veuillez entrer un chiffre : ");
        // Scanner n'importe quoi pour vider le buffer
        scanf("%*s");
    }
    // V�rifie que N est sup�rieur � z�ro
    while (n <= 0)
    {
        printf("N doit etre superieur a zero. Entrer N : ");
        scanf("%d", &n);
    }

    // Calcul de la suite O
    //algo naif =>
    {
        double o[n+1];
        o[1] = 1;
        printf("O[1] = %.3f\n", o[1]);
        // Boucle qui calcule le reste des valeurs de la suite O
        for (unsigned int i = 2; i <= n; i++)
        {
            o[i] = fibonacci_double(i+1) / fibonacci_double(i);
            if (i%5==0) printf("O[%u] = %lf.\n", i,o[i]);
        }
        // Affichage des r�sultats
        printf("Le resultat de O[%d] est %lf.\n", n, o[n]);
    }
    //algo optimise =>
    {
        double o[n+1];
        o[1] = 1;
        printf("O[1] = %.3f\n", o[1]);
        double U0=1, U1=1, U2=1;

        for (unsigned int i = 2; i <= n ; ++i)
        {
            U0 = U1 + U2;
            U2=U1;
            U1=U0;
            if (i%5==0) printf("O[%u] = %lf.\n", i,U1/U2);

        }
        // Affichage des r�sultats

         printf("Le resultat de O[%u] est %lf.\n", n, U1/U2);
    }



    // Calcul et affichage du nombre d'or
    double phi = (1 + sqrt(5)) / 2;
    printf("Le nombre d'or est egal a : %lf.\n", phi);
}
