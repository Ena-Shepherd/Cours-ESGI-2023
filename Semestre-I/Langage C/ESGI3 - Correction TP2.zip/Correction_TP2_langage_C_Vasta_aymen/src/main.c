#include <stdio.h>
#include <stdlib.h>
#include "PMenu\menu.h"
//#include <locale.h>

int main()
{
    //setlocale(LC_CTYPE,"");
	//Lance la fonction Menu.
	Menu();

	//Finish.
	return 0;
}
