#include <stdio.h>
#include <stdlib.h>
#include "PTP2/TP2.h"
#include "PTP2/fibonacci_nombre_or.h"
#include "PTP2/nombre_fibonacci.h"
#include "PTP2/second_degre.h"
#include "PTP2/suite_un.h"
#include "PTP2/quatre_deux_un.h"


void TP2_Ex1()
{
	//Lance la fonction.
	Second_degre();
}

void TP2_Ex2()
{
	//Lance la fonction.
	Suite_un();
}

void TP2_Ex3()
{
	//Lance la fonction.
	Fibonacci();
}

void TP2_Ex4()
{
	//Lance la fonction.
	Fibonacci_nombre_or();
}

void TP2_Ex5()
{
	//Lance la fonction.
	quatre_deux_un();
}
