#include <stdio.h>
#include "PTP1/etoiles.h"

void Etoiles()
{
	//Initie la variable.
	unsigned int nb = 0;

	//Récupère le nombre de l'utilisateur.
	printf("Entrez la taille du sapin : ");
	scanf("%u", &nb);

	for ( unsigned short int i =1; i <= nb; ++i)
    {
        for ( unsigned short int j = 1; j <= (nb-i+1); ++j) printf(" ");
        for ( unsigned short int j = 1; j <= 2*i-1 ; ++j) printf("*");
        printf("\n");
    }
    for ( unsigned short int j = 1; j <= (nb-1); ++j) printf(" ");
    printf("***\n");

	//Affiche Joyeux Noêl.

	for ( unsigned short int j = 1; j <= 2*nb+2 ; ++j) printf("*");
	printf(" Joyeux Noel *************\n");
}
