#include "PTP2/second_degre.h"
#include <stdio.h>
#include <math.h>

unsigned short equation2(double a, double b, double c, double res[2] ) {
    double delta = b * b - 4 * a * c;
    // Si delta > 0
    if (delta > 0) {
        // Calculer x1 et x2
        res[0] = (-b + sqrt(delta)) / (2. * a);
        res[1] = (-b - sqrt(delta)) / (2. * a);
        return 2;
    }
    // Si delta = 0
    else if (delta == 0) {
        // Calculer x1
        res[0] = -b / (2 * a);
       return 1;
    }
    return 0;
}

void Second_degre(void)
{
	double a, b, c;
    double res[2];
    unsigned short nb;

    // Resoudre l equation du second degre : Ax2 + Bx + C = 0
    printf("Resoudre l equation du second degre : Ax2 + Bx + C = 0\n");

    // Entrer A
    printf("Entrer A : ");
    // Tant que scanf n'a pas r�ussi � lire un double
    while(scanf("%lf", &a) != 1) {
        // Afficher un message d'erreur
        printf("Veuillez entrer un chiffre : ");
        // Scanner n'importe quoi pour vider le buffer
            scanf("%*s");
    }

    // Entrer B
    printf("Entrer B : ");
    // Tant que scanf n'a pas r�ussi � lire un double
    while(scanf("%lf", &b) != 1) {
        // Afficher un message d'erreur
        printf("Veuillez entrer un chiffre : ");
        // Scanner n'importe quoi pour vider le buffer
        scanf("%*s");
    }

    // Entrer C
    printf("Entrer C : ");
    // Tant que scanf n'a pas r�ussi � lire un double
    while(scanf("%lf", &c) != 1) {
        // Afficher un message d'erreur
        printf("Veuillez entrer un chiffre : ");
        // Scanner n'importe quoi pour vider le buffer
        scanf("%*s");
    }

    // Calculer delta
    nb = equation2( a,  b,  c,  res) ;

    //printf("%lf %lf %lf\n",a,b,c);

    switch ( nb ){
     case 2 : printf("L equation admet 2 solutions qui sont : %.4lf et %.4lf\n", res[0], res[1]);break;
     case 1  : printf("L equation admet 1 solution qui est : %.4lf\n", res[0]);break;
     default : printf("L equation n admet pas de solution\n");
    }
}
