#include "PTP1/calcul_surface.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI_30 3.14159265358979323846264338379


void CalculSurface()
{
	//Initie les variables.
	unsigned nb = 0;
	double cm = 0.0;

	//Demande le nombre de côtés.
	printf("Entrez le nombre de côté : ");
	if ( scanf("%u", &nb) <= 1 ) exit(1);

	//Demande la longueur des côtés.
	printf("Entrez la longueur d'un côté : ");
	if ( scanf("%lf", &cm) == 0 ) exit(2);

	//Calcul la surface et l'affiche.
	double clc = (nb * pow(cm, 2)) / (4 * tan( PI_30 / nb));
	printf("Le résultat est : %lf\n", clc);
}
