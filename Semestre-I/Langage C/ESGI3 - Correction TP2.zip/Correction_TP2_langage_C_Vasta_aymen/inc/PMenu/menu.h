#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

/*
	* @brief Affiche le menu principal.
*/
void Menu();

#endif // MENU_H_INCLUDED
