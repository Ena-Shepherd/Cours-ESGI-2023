#ifndef SUITE_H_INCLUDED
#define SUITE_H_INCLUDED

/*
	* @Brief Calculer la somme des n premiers termes de la suite 
*/
void Suite();

#endif // SUITE_H_INCLUDED#pragma once
