#ifndef ETOILES_H_INCLUDED
#define ETOILES_H_INCLUDED

/*
	* @brief Affcihe un sapin en ASCII selon la dimension souhaité.
*/
void Etoiles();

#endif // ETOILES_H_INCLUDED