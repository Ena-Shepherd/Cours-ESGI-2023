#ifndef CALCUL_SURFACE_H_INCLUDED
#define CALCUL_SURFACE_H_INCLUDED

/*
	* @brief Calcul de la surface d'un rectangle.
*/
void CalculSurface();

#endif // CALCUL_SURFACE_H_INCLUDED