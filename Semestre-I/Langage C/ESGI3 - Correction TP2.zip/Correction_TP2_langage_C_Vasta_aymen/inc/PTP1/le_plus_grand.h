#ifndef LE_PLUS_GRAND_H_INCLUDED
#define LE_PLUS_GRAND_H_INCLUDED

/*
	* @brief Affiche le plus grand nombre dans une série donnée par l'utilisateur.
*/
void LePlusGrand();

#endif // LE_PLUS_GRAND_H_INCLUDED