#ifndef EXERCICE_H_INCLUDED
#define EXERCICE_H_INCLUDED

/*
	* @brief Lance l'exercie 1.
*/
void TP1_Ex1();

/*
	* @brief Lance l'exercie 2.
*/
void TP1_Ex2();

/*
	* @brief Lance l'exercie 3.
*/
void TP1_Ex3();

/*
	* @brief Lance l'exercie 5.
*/
void TP1_Ex5();

/*
    * @brief Lance l'exercie 6.
*/void TP1_Ex6();

/*
	* @brief Lance l'exercie 7.
*/
void TP1_Ex7();

/*
	* @brief Lance l'exercie 8.
*/
void TP1_Ex8();

#endif // EXERCICE_H_INCLUDED
