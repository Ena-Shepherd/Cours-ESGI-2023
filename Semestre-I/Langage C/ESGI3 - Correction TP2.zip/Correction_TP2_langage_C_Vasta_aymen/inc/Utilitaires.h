#ifndef UTILITAIRES_H_INCLUDED
#define UTILITAIRES_H_INCLUDED
#include <string.h>
inline void fclean (char *s_buffer, FILE * stream)
{
   if (s_buffer != NULL && stream != NULL)
   {
      char *pc = strchr (s_buffer, '\n');

      if (pc != NULL)           /* La saisie n'a pas ete tronquee */
      {
         /* On remplace '\n' par le caractere nul '\0' */
         *pc = 0;
      }
      else
      {
         /* La saisie a ete tronquee, on purge le flux d'entree */
         int c;
         while ((c = fgetc (stream)) != '\n' && c != EOF)
         {
         }
      }
   }
}

inline void cleanin (char *s_buffer)
{
   fclean(s_buffer,stdin);
}
#endif // UTILITAIRES_H_INCLUDED
