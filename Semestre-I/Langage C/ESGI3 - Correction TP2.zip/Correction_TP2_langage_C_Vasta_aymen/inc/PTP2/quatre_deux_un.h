#ifndef QUATRE_DEUX_UN_H_INCLUDED
#define QUATRE_DEUX_UN_H_INCLUDED
void quatre_deux_un();

#endif // QUATRE_DEUX_UN_H_INCLUDED
