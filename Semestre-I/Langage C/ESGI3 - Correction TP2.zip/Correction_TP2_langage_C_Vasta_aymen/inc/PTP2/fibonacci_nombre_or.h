#ifndef FIBONACCI_NOMBRE_OR_H_INCLUDED
#define FIBONACCI_NOMBRE_OR_H_INCLUDED

/*
* @brief Le nombre d�or & Fibonacci.
*/

void Fibonacci_nombre_or();

#endif // FIBONACCI_NOMBRE_OR_H_INCLUDED
