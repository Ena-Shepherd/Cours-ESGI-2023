#ifndef SECOND_DEGRE_H_INCLUDED
#define SECOND_DEGRE_H_INCLUDED

/*
	* @brief  R�soudre une �quation du second degr�.
*/
void Second_degre();
unsigned short equation2(double a, double b, double c, double res[2] );
#endif // SECOND_DEGRE_H_INCLUDED
