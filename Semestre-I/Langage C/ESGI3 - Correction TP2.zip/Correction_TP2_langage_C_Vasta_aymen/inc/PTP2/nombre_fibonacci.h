#ifndef NOMBRE_FIBONACCI_H_INCLUDED
#define NOMBRE_FIBONACCI_H_INCLUDED

/*
	* @brief Le nombre de Fibonacci.
*/
void Fibonacci();

#endif // NOMBRE_FIBONACCI_H_INCLUDED
