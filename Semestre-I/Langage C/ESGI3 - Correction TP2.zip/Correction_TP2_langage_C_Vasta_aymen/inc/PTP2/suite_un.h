#ifndef SUITE_UN_H_INCLUDED
#define SUITE_UN_H_INCLUDED

/*
	* @brief  Programmer une suite.
*/
void Suite_un();

#endif // SUITE_UN_H_INCLUDED
