#ifndef TP2_H_INCLUDED
#define TP2_H_INCLUDED

#include "Utilitaires.h"
/*
	* @brief Lance l'exercie 1.
*/
void TP2_Ex1();

/*
	* @brief Lance l'exercie 2.
*/
void TP2_Ex2();

/*
	* @brief Lance l'exercie 3.
*/
void TP2_Ex3();

/*
	* @brief Lance l'exercie 4.
*/
void TP2_Ex4();

/*
	* @brief Lance l'exercie 5.
*/
void TP2_Ex5();


#endif // EXERCICE_H_INCLUDED
