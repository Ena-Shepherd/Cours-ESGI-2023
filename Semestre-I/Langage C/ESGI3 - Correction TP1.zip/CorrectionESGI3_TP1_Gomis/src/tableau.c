#include <stdio.h>
#include "PTP1/tableau.h"

void Tableau()
{
    //Déclaration des variables
    int nb = -1;
    //Boucle tant que l'utilisateur veut continuer.
    while (0 == 0 )
    {
        //Demande à l'utilisateur de saisir la taille du tableau.
        printf("Entrer la taille de votre tableau : (max 10) (0 : Return)\n");
        scanf_s("%d", &nb);

        //Vérification de la taille du tableau, si 0 : l'utilisateur veut arrêter.
        if (nb == 0 || nb < 0 )  break;

        //Déclaration des variables.
        double tab[nb+1][nb+1] ;
        for (int i = 0; i < nb; i++)
        {
                tab[i][nb]=tab[nb][i]=0;
        }
        tab[nb][nb] = 0 ;

        //Boucle pour remplir le tableau.
        for (int i = 0; i < nb; i++)
        {
            for (int j = 0; j < nb; j++)
            {
                printf("Entrer le nombre [%d][%d] : ",i,j);
                scanf_s("%lf", &tab[i][j]);
                tab[i][nb]+=tab[i][j];
                tab[nb][j]+=tab[i][j];
            }
            tab[nb][nb]+=tab[i][nb];
        }

        for (int i = 0; i <= nb; i++)
        {
            for (int j = 0; j <= nb; j++)
            {
                if (j==nb || i==nb)
                printf("\t(%5.2lf) ",tab[i][j]/nb);
                    else
                printf("\t %5.2lf  ",tab[i][j]);
            }
            printf("\n");

        }

        printf("\n");
    }
}
