#include <stdio.h>
#include "PTP1\le_plus_grand.h"

void LePlusGrand()
{
    const short int TAILLE = 5;
	//Déclarations de variables.
	int big[3] ;
    printf("Entrez le nombre dans n°1 que vous souhaitez stockez : ");
    scanf_s("%d", &big[2]);
    printf("\n");
    big[0]=1;
    big[1]=big[2];
	//Boucle sur la grandeur du tableau.
	for (int i = 2; i <= TAILLE; ++i)
	{
		//Demande à l'utilisateur de rentrer un nombre.
		printf("Entrez le nombre dans n°%d que vous souhaitez stockez : ", i);
		scanf_s("%d", &big[2]);
		printf("\n");

		//Vérifie si le nombre est plus grand que le précédent.
		if (big[2] > big[1])
		{
			//Stock le nombre le plus grand et son index.
			big[0] = i;
			big[1] = big[2];
		}
	}

	//Affiche le nombre le plus grand et son index.
	printf("Le nombre le plus grand se trouve à l'index : %d et contenais : %d\n", big[0], big[1]);
}
