#include <stdio.h>
#include "PTP1/suite.h"

void Suite()
{
	//Déclaration des variables.
    int nb = 0;
    double total = 0;

	//Tant que l'utilisateur souhaite continuer.
    do
    {
		//Déclaration des variables.
        total = 1;
		//Demande à l'utilisateur un nombre.
        printf("Entrez le nombre de terme de la suite a calculer n avec n > 0 (0 : Return) : ");
        scanf_s("%d", &nb);

		//Vérifie que le nombre est positif.
        if (nb < 0)
        {
            printf("Le nombre doit être positif.\n");
        }
        else
        {
			//Lance le calcul.
            for (unsigned int i = 2; i <= nb; total += 1. / i++);
			//Affiche le résultat.
            printf("U%d est : %.4lf \n", nb, total);
        }
    } while (nb != 0);
}
