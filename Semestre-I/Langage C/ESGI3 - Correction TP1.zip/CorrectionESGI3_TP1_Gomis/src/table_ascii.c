#include <stdio.h>
#include "PTP1/table_ascii.h"

void Table_Ascii()
{
	//Boucle entre 33 et 126.
	for (unsigned short int i = 33; i < 127; i++)
	{
		//Sépare l'affichage ASCII en fonction des dizaines.
		if (i % 10 == 0 )  printf("\n");
        printf("[%d, %c] ", i, i);

	}
}
