#ifndef TABLE_ASCII_H_INCLUDED
#define TABLE_ASCII_H_INCLUDE

/*
	* @brief Affiche la table ASCII.
*/
void Table_Ascii();

#endif // TABLE_ASCII_H_INCLUDED