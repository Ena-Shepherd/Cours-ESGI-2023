#ifndef TABLEAU_H_INCLUDED
#define TABLEAU_H_INCLUDE

/*
	* @brief Affiche un tableau avec une moyenne horizontale et verticale.
*/
void Tableau();

#endif // TABLEAU_H_INCLUDED