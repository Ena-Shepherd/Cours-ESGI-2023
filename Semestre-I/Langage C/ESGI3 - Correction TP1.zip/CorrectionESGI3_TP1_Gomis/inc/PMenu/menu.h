#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

/*
	* @brief Affiche le menu principal.
*/
void Menu();

/*
	* @brief Affiche le menu du premier TP.
*/
void MenuTP1();

/*
	* @brief Affiche le menu du second TP.
*/
void MenuTP2();

#endif // MENU_H_INCLUDED