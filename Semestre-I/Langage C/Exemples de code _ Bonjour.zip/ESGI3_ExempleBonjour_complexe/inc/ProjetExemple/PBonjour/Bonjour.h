#ifndef BONJOUR_H_INCLUDED
#define BONJOUR_H_INCLUDED

void Bonjour();
void Bonjour1(const char* msg);

void ProjetExemple_PBonjour_Bonjour();
void ProjetExemple_PBonjour_Bonjour1(const char* msg);


#endif // BONJOUR_H_INCLUDED
