#include "ProjetExemple/PTest/TestBonjour.h"

int main()
{
    TestBonjour();
    return 0;
}
