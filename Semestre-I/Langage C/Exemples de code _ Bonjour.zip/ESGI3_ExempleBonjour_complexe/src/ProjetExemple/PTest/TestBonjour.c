#include "ProjetExemple/PBonjour/Bonjour.h"
#include "ProjetExemple/PTest/TestBonjour.h"


void TestBonjour() {

    Bonjour();
    Bonjour1(" Long live the c !!!!");
    ProjetExemple_PBonjour_Bonjour();
    ProjetExemple_PBonjour_Bonjour1(" Vive le c !!!!");
}
