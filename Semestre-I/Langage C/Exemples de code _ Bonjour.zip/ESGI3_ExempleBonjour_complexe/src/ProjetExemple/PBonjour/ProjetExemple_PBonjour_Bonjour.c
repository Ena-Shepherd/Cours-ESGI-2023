#include "ProjetExemple/PBonjour/Bonjour.h"
#include <stdio.h>

void ProjetExemple_PBonjour_Bonjour() {
        printf("Bonjour! \n");
}

void ProjetExemple_PBonjour_Bonjour1(const char* msg) {
    printf("Bonjour! %s\n",msg);
}
