#include "ProjetExemple/PBonjour/Bonjour.h"
#include <stdio.h>

void Bonjour() {
    printf("Hello world! \n");
}

void Bonjour1(const char* msg) {
    printf("Hello world! %s\n", msg );
}
