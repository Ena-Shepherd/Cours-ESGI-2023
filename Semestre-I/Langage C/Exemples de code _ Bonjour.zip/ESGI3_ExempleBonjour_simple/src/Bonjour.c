#include "PExemple/Bonjour.h"
#include <stdio.h>

void Bonjour() {
    printf("Hello world!\n");
}
void Bonjour1(const char* msg) {
     printf("Hello world 1! %s \n",msg);
}
void PExemple_Bonjour() {
    printf("Hello world!\n");
}
