
#include "PExemple/Bonjour.h"

int main()
{
    Bonjour();
    Bonjour1(" CouCou ") ;
    PExemple_Bonjour() ;
    return 0;
}
