#ifndef BONJOUR_H_INCLUDED
#define BONJOUR_H_INCLUDED


void Bonjour() ;
void Bonjour1(const char* msg) ;
void PExemple_Bonjour() ;

#endif // BONJOUR_H_INCLUDED
