from utilitary import *

def exo_2():
    """
    Script permettant de calculer la surface d'un trapèze
    """
    
    # Saisie des variables
    a = verif_1error("Entrer la longueur du côté a : ",0)
    b = verif_1error("Entrer la longueur du côté b : ",0)
    h = verif_1error("Entrer la hauteur h : ",0)

    if not all([a.isdigit(), b.isdigit(), h.isdigit()]):
        print("Erreur, vous n'avez pas entré un entier")
        return

    a, b, h = int(a), int(b), int(h)

    # Calcul de la surface
    surface = (a + b) * h * 0.5

    # Affichage de la surface
    try :
        print(f"La surface du trapèze est de {surface} m")
        points = [[0, 0], [a/3, h], [(a+2)/3, h], [a, 0], [(a+2)/3, 0], [(a+2)/3, h], [(a+2)/3, 0], [a/3, 0], [a/3, h], [a/3, 0], [0, 0]]
        plt.plot(*zip(*points))
        plt.show()
    except:
        print (f"""Avant de lancer le code il faut installer toutes les librarires utiles au bon fonctionnement du Tp :
                pip install -r requirements.txt""")
              

        
