from utilitary import *

def exo_4():
    """
    Script permettant de dessiner un arbre de noël
    """

    # Saisie de la hauteur de l'arbre
    hauteur = verif_1error("Hauteur de l'arbre : ",0)

    # Dessin de l'arbre entouré de =
    for i in range(hauteur):
        print(f"{'=' * (hauteur - i)}{'*' * (2 * i + 1)}{'=' * (hauteur - i)}")

    # Dessin de la base de l'arbre
    print("="*hauteur + "*" + "="*hauteur)
    print("="*(hauteur-1) + "***" + "="*(hauteur-1))
