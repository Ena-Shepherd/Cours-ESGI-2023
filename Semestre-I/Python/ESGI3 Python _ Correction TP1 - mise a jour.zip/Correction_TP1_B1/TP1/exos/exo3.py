from utilitary import *
import  math

def exo_3():
    """
    Script permettant de calculer la somme et la factorielle d'un nombre
    """
    while True:

        number = verif_1error("Entrer un entier positif : ",0)

        somme, factorielle = 0, math.factorial(number)
        number_used_in_str = []

        # Un autre moyen de faire la somme et la factorielle mais on utilise sum() et listcomprehension ce qui nous 
        # fait boucler 2 fois sur la liste des nombres, ce qui n'est pas très optimisé :)
        
        # somme = sum(range(1, number + 1))
        # factorielle = math.factorial(number)
        # numbers_used_in_str = [str(i) for i in range(1, number + 1)]
        
        # Calcul de la somme et de la factorielle
        for i in range(1, number + 1):
            somme += i
            number_used_in_str.append(str(i))

        # Affichage de la somme
        print(" + ".join(number_used_in_str), "=", somme)
        print(somme, "=", " + ".join(number_used_in_str))

        # Affichage de la factorielle
        print(" * ".join(number_used_in_str), "=", factorielle)
        print(factorielle, "=", " * ".join(number_used_in_str))

        if input("Voulez-vous continuer ? (o/n) : ") == 'n':
            break
