from utilitary import *
from math import *

def exo_5():
    """
    Script permettant de saisir un entier au clavier et d'afficher :
        • logarithme népérien de l’entier
        • sinus de l’entier
        • cosinus de l’entier
    """
    entier = verif_1error("Entrer un entier positif: ",0)

    print(f"log({entier}) = {log(entier)}")
    print(f"sin({entier}) = {sin(entier)}")
    print(f"cos({entier}) = {cos(entier)}")
