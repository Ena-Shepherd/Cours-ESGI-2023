from utilitary import *
from tqdm import tqdm
import math

def U(n: int) -> float:
    """
    Calcul de la suite U
    :param n: int

    :return: float
    """
    somme = 1
    fact = 1
    for i in tqdm(range(1, n+1), desc="Calcul de U"):
        fact *= i
        somme += 1./fact
    return somme

def V(n: int) -> float:
    """
    Calcul de la suite V
    :param n: int

    :return: float
    """
    fact = 1
    result = 1
    for i in tqdm(range(1, n+1), desc="Calcul de V"):
        fact *= i
        result += 1/fact
    return result + 1 / (fact * n ) 

    # return U(n) + 1/(n * factorial(n)) <- c'est moins rapide OwO

def exo_7():
    print(U(verif_1error("Entrer la valeur de n : ",0)))
    print(V(verif_1error("Entrer la valeur de n : ",0)))

