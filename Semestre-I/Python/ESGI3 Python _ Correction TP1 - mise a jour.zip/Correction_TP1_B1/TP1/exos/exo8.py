from utilitary import *
from tqdm import tqdm
import math

def exo_8():
    """
    Calcul de la probabilité de gagner au tiercé, quarté, quinté...
    """
    # Demande du nombre de chevaux partants et de chevaux joués à l'utilisateur
    N = verif_1error("Nombre de chevaux partants : ",0)
    P = verif_2error("Nombre de chevaux joués : ",0,(N+1))

    n, np,p = math.factorial(N), math.factorial(N-P),math.factorial(P)

    X =  n / np
    Y =  n / (p *  np)
    
    # Affichage des chances de gagner
    print(f"Une chance sur {int(X)} de gagner dans l'ordre")
    print(f"Une chance sur {int(Y)} de gagner dans le désordre")

    #-------> le plus rapide
    fact = 1
    for i in range(1, N+1):
          fact *= i
          if ( i == (N-P)):
              np=fact
          if ( i == P) :
              p =fact
    n=fact
    X =  n / np
    Y =  n / (p *  np)
  
    # Affichage des chances de gagner
    print(f"Une chance sur {int(X)} de gagner dans l'ordre")
    print(f"Une chance sur {int(Y)} de gagner dans le désordre")

    #---------------------------------> le plus rapide
    fact = 1
    if N-P < P :
        for i in range(1, N-P+1):
            fact *= i
        np=fact
    
        for i in range(N-P+1,P+1):
            fact *= i
        p =fact
        for i in range(P+1,N+1):
            fact *= i    
        n=fact
    else:
        for i in range(1,P+1):
            fact *= i
        p =fact
        
        for i in range(P+1, N-P+1):
            fact *= i
        np=fact
        for i in range(N-P+1,N+1):
            fact *= i    
        n=fact

    X =  n / np
    Y =  X / p
   
    # Affichage des chances de gagner
    print(f"Une chance sur {int(X)} de gagner dans l'ordre")
    print(f"Une chance sur {int(Y)} de gagner dans le désordre")

