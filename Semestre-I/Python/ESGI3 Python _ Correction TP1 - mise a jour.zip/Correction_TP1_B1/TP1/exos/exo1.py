from utilitary import *

def exo_1():
    """
    Script permettant de rentrer 1 caractères et un entier
    Afficher la variables sous forme d'entiers et de caractères
    """

    while True:
        # Saisie des variables
        caractere = input("Entrer un caractère : ")

        if len(caractere) != 1:
            print("Erreur, vous n'avez pas entré un caractère")
            continue
        
        #entier = input("Entrer un entier : ")
        #if not entier.isdigit():
        #    print("Erreur, vous n'avez pas entré un entier")
        #    continue 

        entier = verif_2error("Entrer un entier positif et inferieur a 256 : ",0,256)

        # Affichage des variables
        print(f'{caractere} vaut {ord(caractere)}')
        print(f'{entier} vaut {chr(entier)}')

        if input("Voulez-vous continuer ? (o/n) : ") == 'n':
            break
