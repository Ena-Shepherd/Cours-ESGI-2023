from utilitary import *
from tqdm import tqdm
import math

def f1(x: float, n: int) -> float:
    """
    Calcul de la fonction f1(x,n) = x^n / n!
    :param x: float
    :param n: int

    :return: float
    """
    return x ** n / Decimal(factorial(n))

def Res(x: float, N: int) -> float:
    """
    Calcul de la somme de f1(x,n) pour n allant de 1 à N
    :param x: float
    :param N: int

    :return: float
    """
    somme = 1
    fact = 1
    for n in tqdm(range(1, N+1), desc="Calcul de la somme"):
        fact *= n
        #somme += x ** n / fact
        somme += x / fact
        x*=x
    return somme



# Exercice 6 : Permet d'afficher le logarithme népérien, le sinus et le cosinus de l'entier choisit
def exo_6():
     x=verif_2error_float("Entrer la valeur de x : ",0,1)
     print(Res(x,verif_1error("Entrer la valeur de N : ",0)))
     print(f"math.exp({x}) = {math.exp(x)}")

