from menu import *


# Permet de lancer le menu via la fonction main
def main():
    menu()


if __name__ == "__main__":
    main()
