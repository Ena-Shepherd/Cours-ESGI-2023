from exos import *
from utilitary import *


# Fonction de lancement du menu pour le choix des exercices disponibles
def menu():
    while True:
        print("\n\nListe des exercices du TP1 disponibles :\n")
        print("Exercice 1 > Types prédéfinis")
        print("Exercice 2 > Calcul d’une surface")
        print("Exercice 3 > Somme & factoriel")
        print("Exercice 4 > Arbre de noël")
        print("Exercice 5 > math")
        print("Exercice 6 > Fonctions")
        print("Exercice 7 > Fonctions")
        print("Exercice 8 > le tierce")
        print("0 > Quitter\n")
        choice = verif_1error("Choisissez l'exercice voulu : ")
        print("\n\n\n")
        match choice:
            case 0:
                print("Très bien, au revoir...")
                return
            case 1:
                 exo_1()
            case 2:
                exo_2()
            case 3:
                exo_3()
            case 4:
                exo_4()
            case 5:
                 exo_5()
            case 6:
                 exo_6()
            case 7:
                 exo_7()
            case 8:
                 exo_8()
        if not choice_():
            print("Très bien, au revoir...")
            return
