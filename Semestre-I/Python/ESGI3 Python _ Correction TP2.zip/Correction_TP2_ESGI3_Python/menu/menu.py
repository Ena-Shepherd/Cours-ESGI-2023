from exos import *
from utilitary import *


# Fonction de lancement du menu pour le choix des exercices disponibles
def menu():
    while True:
        print("""\n\nListe des exercices disponibles :\n
        Exercice 1 > Calcul de Surface
        Exercice 2 > Jeu des allumettes
        Exercice 3 > Les Fichiers
        Exercice 4 > Livre
        Exercice 5 > Roman
        Exercice 6 > Fiche Roman
        0 > Quitter\n""")
        choice = verif_1error("Choisissez l'exercice voulu : ")
        print("\n\n\n")
        match choice:
            case 0:
                print("Très bien, au revoir...")
                return
            case 1:
                 exo_1()
            case 2:
                exo_2()
            case 3:
                exo_3()
            case 4:
                exo_4()
            case 5:
                 exo_5()
            case 6:
                 exo_6()
        if not choice_():
            print("Très bien, au revoir...")
            return
