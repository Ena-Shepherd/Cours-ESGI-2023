from utilitary import *


# fonction qui retourne le carré de la valeur d'entrée
def carre(a):
    return a * a

def exo_1():
    print("\n----------Exercice 1 - Calcul de Surface----------\n")

    # l'utilisateur entre la valeur de "a"
    a = verif_2error_float("Entrer a : ")

    # l'utilisateur entre la valeur de "b"
    b = verif_2error_float("Entrer b : ")

    # l'utilisateur entre la valeur de "p" qui est un float
    p = verif_2error_float("Entrer p : ")

    # information sur les valeurs entrées pour "a", "b", et "p"
    print("Calcul de l'intégrale de la fonction y = x * x avec", a, "<= x <", b, "et p =", p)

    # initialisation de la variable qui contiendra la somme finale
    S = 0

    while a < b:
        # somme des produits entre la fonction "carre" et "p"
        S += carre(a) * p
        # incrémentation de "a" par "p"
        a += p

    # le résultat final est stocké dans "resultat"
    resultat = S

    # affichage du résultat avec un nombre à deux décimales
    print("Résultat :", "%.2f" % resultat)    
    print("\n----------Exercice 1 - Calcul de Surface----------\n")
