from utilitary import *

class Livre:
    # Déclarer les attributs d'un livre
    def __init__(self, nom=None, auteur=None, maison_edition=None, code_barre=None,):
        self.__a_nom = nom
        self.__a_auteur = auteur
        self.__a_maison_edition = maison_edition
        self.__a_code_barre = code_barre

    @property
    def nom(self) :
            return self.__a_nom
    @property
    def auteur (self) :
            return self.__a_auteur 

    @property
    def code_barre(self) :
            return self.__a_code_barre

    @property
    def maison_edition(self) :
            return self.__a_maison_edition

    @nom.setter
    def nom(self,value) :
            self.__a_nom = value
    @auteur.setter
    def auteur (self,value) :
            self.__a_auteur = value

    @code_barre.setter
    def code_barre(self,value) :
            self.__a_code_barre= value

    @maison_edition.setter
    def maison_edition(self,value) :
            self.__a_maison_edition= value

    # Demander et affecter les valeurs pour les attributs d'un livre
    def creation(self):
        self.nom = input("Entrez le nom du livre : ")
        self.auteur = input("Entrez le nom de l'auteur : ")
        self.maison_edition = input("Entrez le nom de la maison d'édition : ")
        self.code_barre = input("Entrez le code barre : ")

    # Modifier les valeurs des attributs d'un livre
    def modification(self, nom=None, auteur=None, maison_edition=None, code_barre=None):
        if nom:
            self.nom = nom
        if auteur:
            self.auteur = auteur
        if maison_edition:
            self.maison_edition = maison_edition
        if code_barre:
            self.code_barre = code_barre

    # Afficher les informations d'un livre
    def affichage_informations(self):
        print("Nom du livre :", self.nom)
        print("Auteur :", self.auteur)
        print("Maison d'édition :", self.maison_edition)
        print("Code barre :", self.code_barre)

    # Fonction pour tester la classe Livre
    @staticmethod
    def test_livre():
        mon_livre = Livre()
        choix = None
        while choix != "q":
            print("\n1. Créer un livre")
            print("2. Modifier un livre")
            print("3. Afficher les informations d'un livre")
            print("q. Quitter")
            choix = input("\nEntrez votre choix : ")
            if choix == "1":
                mon_livre.creation()
            elif choix == "2":
                mon_livre.modification(nom=input("Entrez le nom du livre : "),
                                       auteur=input("Entrez le nom de l'auteur : "),
                                       maison_edition=input("Entrez le nom de la maison d'édition : "),
                                       code_barre=input("Entrez le code barre : "))
            elif choix == "3":
                mon_livre.affichage_informations()
            elif choix == "q":
                break
            else:
                print("Choix non valide")

def exo_4():
    print("\n----------Exercice 4 - Classe Livre----------\n")   
    # Tester
    Livre.test_livre()
    print("\n----------Exercice 4 - Classe Livre----------\n")   
