import os
from utilitary import *

def fichier_bin():
        # saisir les deux entiers
        while True:
            try :
                num1 = verif_2error("Entrer le premier nombre entier du fichier binaire : ")
                num2 = verif_2error("Entrer le second nombre entier du fichier binaire : ")
                break
            except ValueError:
                print("Vous devez saisir un nombre entier.")
            
        # ouvrir le fichier binaire en mode écriture binaire
        with open(os.path.join(os.getcwd(), "BDD.bin"), "wb") as fichier_binaire:
            # écrire les deux entiers dans le fichier binaire
            fichier_binaire.write(num1.to_bytes(4, "big"))
            fichier_binaire.write(num2.to_bytes(4, "big"))
            
def fichier_txt():
        # saisir les deux entiers
        while True:
            try :
                num1 = verif_2error("Entrer le premier nombre entier du fichier texte : ")
                num2 = verif_2error("Entrer le second nombre entier du fichier texte : ")
                break
            except ValueError:
                print("Vous devez saisir un nombre entier.")
        
        # ouvrir le fichier texte en mode écriture
        with open(os.path.join(os.getcwd(), "BDD.txt"), "w") as fichier_text:
            # écrire les deux entiers dans le fichier texte sous forme de chaîne
            fichier_text.write(str(num1) + "\n")
            fichier_text.write(str(num2) + "\n")
    
def lire_bin():
        # ouvrir le fichier binaire en mode lecture binaire
        with open("BDD.bin", "rb") as fichier_binaire:
            # lire les deux entiers depuis le fichier binaire
            num1 = int.from_bytes(fichier_binaire.read(4), "big")
            num2 = int.from_bytes(fichier_binaire.read(4), "big")
    
        print("\nLes nombres lus dans le fichier binaire sont :", num1, "et", num2)
    
def lire_txt():
        # ouvrir le fichier texte en mode lecture
        with open("BDD.txt", "r") as fichier_text:
            # lire les deux nombres depuis le fichier texte
            num1 = int(fichier_text.readline().strip())
            num2 = int(fichier_text.readline().strip())
    
        print("Les nombres lus dans le fichier texte sont :", num1, "et", num2)

def exo_3():
    print("\n----------Exercice 3 - Les Fichiers----------\n")    

    # appeler les fonctions pour les tester
    fichier_bin()
    fichier_txt()
    lire_bin()
    lire_txt()

    print("\n----------Exercice 3 - Les Fichiers----------\n")
