from .exo4 import Livre
#Classe dérivée de Livre pour définir les spécificités d'un roman
class Roman(Livre):
    # Initialise les attributs hérités de la classe Livre et définit les attributs spécifiques à un roman
    def __init__(self, nom=None, auteur=None, maison_edition=None, code_barre=None, type_roman=None, description=None):
        Livre.__init__(self, nom, auteur, maison_edition, code_barre)
        self.__a_type_roman = type_roman
        self.__a_description = description

    @property
    def type_roman(self) :
            return self.__a_type_roman
    @property
    def description (self) :
            return self.__a_description
    @type_roman.setter
    def type_roman(self,value) :
            value = self.__a_type_roman
    @description.setter
    def description (self,value) :
            value = self.__a_description
            
    # Appelle la méthode creation de la classe Livre pour définir les informations de base d'un livre et
    # demande les informations spécifiques à un roman (type et description)
    def creation(self):
        Livre.creation(self)
        self.type_roman = input("Entrez le type de roman : ")
        self.description = input("Entrez une description du type de roman : ")

    # Appelle la méthode modification de la classe Livre pour définir les informations de base d'un livre et
    # modifie les informations spécifiques à un roman si elles sont passées en argument
    def modification(self, nom=None, auteur=None, maison_edition=None, code_barre=None, type_roman=None, description=None):
        Livre.modification(self, nom, auteur, maison_edition, code_barre)
        if type_roman:
            self.type_roman = type_roman
        if description:
            self.description = description

        # Affiche les informations de base d'un livre ainsi que les informations spécifiques à un roman
    def affichage_informations(self):
        Livre.affichage_informations(self)
        print("Type de roman :", self.type_roman)
        print("Description :", self.description)

    # Fonction pour tester la classe Roman en permettant de créer, de modifier ou d'afficher les informations d'un roman
    @staticmethod
    def test_roman():
        mon_roman = Roman()
        choix = None
        while choix != "q":
            print("\n1. Créer un roman")
            print("2. Modifier un roman")
            print("3. Afficher les informations d'un roman")
            print("q. Quitter")
            choix = input("\nEntrez votre choix : ")
            if choix == "1":
                mon_roman.creation()
            elif choix == "2":
                mon_roman.modification(nom=input("Entrez le nom du roman : "),
                                       auteur=input("Entrez le nom de l'auteur : "),
                                       maison_edition=input("Entrez le nom de la maison d'édition : "),
                                       code_barre=input("Entrez le code barre : "),
                                       type_roman=input("Entrez le type de roman : "),
                                       description=input("Entrez une description du type de roman : "))
            elif choix == "3":
                mon_roman.affichage_informations()
            elif choix == "q":
                break
            else:
                print("Choix non valide")
                
def exo_5():
    print("\n----------Exercice 5 - Classe Roman----------\n")   
    
    #
    #Tester
    Roman.test_roman()

    print("\n----------Exercice 5 - Classe Roman----------\n")
