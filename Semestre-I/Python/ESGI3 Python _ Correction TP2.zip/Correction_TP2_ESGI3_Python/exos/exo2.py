import random

from utilitary import *

def jouer_partie(nom_joueur, nb_allumettes):
        # Déterminer qui commence le jeu au hasard
        tour = random.choice([nom_joueur, "Ordinateur"])
        
        # Boucle de jeu jusqu'à ce que toutes les allumettes soient enlevées
        while nb_allumettes > 0:
            # Si c'est au tour du joueur
            if tour == nom_joueur:
                print("| " * nb_allumettes)
                retrait = int(input(f"{tour} enlève : "))
                
                # Vérification de la validité de la sélection de l'utilisateur
                if retrait not in [1, 2, 3]:
                    print("Vous devez enlever 1, 2 ou 3 allumettes")
                    continue
                nb_allumettes -= retrait
            
            # Si c'est au tour de l'ordinateur
            else:
                retrait = random.choice([1, 2, 3])
                nb_allumettes -= retrait
                print(f"Ordinateur enlève : {retrait}")
                print("| " * nb_allumettes)
            
            # Vérification de la fin de la partie
            if nb_allumettes <= 0:
                if tour == nom_joueur:
                    print(f"{nom_joueur} a perdu :-(")
                    print("L’ordinateur a gagné :-)")
                else:
                    print("L’ordinateur a perdu :-(")
                    print(f"{nom_joueur} a gagné :-)")
                break
            
            # Alterner entre les tours de jeu
            if tour == nom_joueur:
                tour = "Ordinateur"
            else:
                tour = nom_joueur
def exo_2():

    print("\n----------Exercice 2 - Jeu des allumettes----------\n")

    # Demander le nom du joueur
    nom_joueur = input("Entrer votre nom : ")
    
    # Demander le nombre d'allumettes à utiliser pour la partie
    nb_allumettes =  verif_2error("Choisir le nombre d'allumettes de départ : ")
    
    # Démarrer la partie
    jouer_partie(nom_joueur, nb_allumettes)
    
    # Afficher qui commence
    print("L'ordinateur commence")
    
    print("\n----------Exercice 2 - Jeu des allumettes----------\n")
